#
# TABLE STRUCTURE FOR: ciauth_user_token
#

DROP TABLE IF EXISTS `ciauth_user_token`;

CREATE TABLE `ciauth_user_token` (
  `token` varchar(90) NOT NULL,
  `email` varchar(45) NOT NULL,
  `tstamp` int(11) NOT NULL,
  PRIMARY KEY (`token`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: ciauth_user_profiles
#

DROP TABLE IF EXISTS `ciauth_user_profiles`;

CREATE TABLE `ciauth_user_profiles` (
  `uprof_id` int(11) NOT NULL AUTO_INCREMENT,
  `profile_user_id_fk` int(11) NOT NULL,
  `first_name` varchar(40) NOT NULL,
  `last_name` varchar(40) NOT NULL,
  `address_1` varchar(60) NOT NULL,
  `address_2` varchar(60) DEFAULT NULL,
  `city` varchar(40) NOT NULL,
  `state` varchar(40) NOT NULL,
  `zip_code` varchar(10) NOT NULL,
  `company_name` varchar(40) DEFAULT NULL,
  `home_phone` varchar(15) DEFAULT NULL,
  `company_phone` varchar(15) DEFAULT NULL,
  `mobile_phone` varchar(15) DEFAULT NULL,
  `face_book_url` varchar(90) DEFAULT NULL,
  `twitter_url` varchar(90) DEFAULT NULL,
  `linkedin_url` varchar(90) DEFAULT NULL,
  `newsletter` char(1) DEFAULT NULL,
  PRIMARY KEY (`uprof_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: ciauth_user_privileges_users
#

DROP TABLE IF EXISTS `ciauth_user_privileges_users`;

CREATE TABLE `ciauth_user_privileges_users` (
  `upriv_id` int(11) NOT NULL AUTO_INCREMENT,
  `upriv_privilege_id_fk` int(11) NOT NULL,
  `upriv_user_id_fk` int(11) NOT NULL,
  PRIMARY KEY (`upriv_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `ciauth_user_privileges_users` (`upriv_id`, `upriv_privilege_id_fk`, `upriv_user_id_fk`) VALUES ('1', '1', '1');
INSERT INTO `ciauth_user_privileges_users` (`upriv_id`, `upriv_privilege_id_fk`, `upriv_user_id_fk`) VALUES ('2', '1', '2');
INSERT INTO `ciauth_user_privileges_users` (`upriv_id`, `upriv_privilege_id_fk`, `upriv_user_id_fk`) VALUES ('3', '1', '3');
INSERT INTO `ciauth_user_privileges_users` (`upriv_id`, `upriv_privilege_id_fk`, `upriv_user_id_fk`) VALUES ('4', '1', '4');
INSERT INTO `ciauth_user_privileges_users` (`upriv_id`, `upriv_privilege_id_fk`, `upriv_user_id_fk`) VALUES ('5', '2', '2');


#
# TABLE STRUCTURE FOR: ciauth_user_privileges_groups
#

DROP TABLE IF EXISTS `ciauth_user_privileges_groups`;

CREATE TABLE `ciauth_user_privileges_groups` (
  `upriv_id` int(11) NOT NULL AUTO_INCREMENT,
  `upriv_privilege_id_fk` int(11) NOT NULL,
  `upriv_group_id_fk` int(11) NOT NULL,
  PRIMARY KEY (`upriv_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `ciauth_user_privileges_groups` (`upriv_id`, `upriv_privilege_id_fk`, `upriv_group_id_fk`) VALUES ('1', '2', '1');


#
# TABLE STRUCTURE FOR: ciauth_user_privileges
#

DROP TABLE IF EXISTS `ciauth_user_privileges`;

CREATE TABLE `ciauth_user_privileges` (
  `privilege_id` int(11) NOT NULL AUTO_INCREMENT,
  `privilege_name` varchar(40) NOT NULL,
  `privilege_description` varchar(200) NOT NULL,
  PRIMARY KEY (`privilege_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

INSERT INTO `ciauth_user_privileges` (`privilege_id`, `privilege_name`, `privilege_description`) VALUES ('1', 'user', 'Minimal level of privilege');
INSERT INTO `ciauth_user_privileges` (`privilege_id`, `privilege_name`, `privilege_description`) VALUES ('2', 'manager', 'Privilege for managers');
INSERT INTO `ciauth_user_privileges` (`privilege_id`, `privilege_name`, `privilege_description`) VALUES ('5', 'Privilège royal', 'Pour les rois');


#
# TABLE STRUCTURE FOR: ciauth_user_groups
#

DROP TABLE IF EXISTS `ciauth_user_groups`;

CREATE TABLE `ciauth_user_groups` (
  `group_id` int(11) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(40) NOT NULL,
  `group_description` varchar(200) NOT NULL,
  PRIMARY KEY (`group_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `ciauth_user_groups` (`group_id`, `group_name`, `group_description`) VALUES ('1', 'manager', 'Managers');


#
# TABLE STRUCTURE FOR: ciauth_user_accounts
#

DROP TABLE IF EXISTS `ciauth_user_accounts`;

CREATE TABLE `ciauth_user_accounts` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(50) NOT NULL,
  `username` varchar(40) NOT NULL,
  `password` varchar(255) NOT NULL,
  `creation_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_login` timestamp NULL DEFAULT NULL,
  `admin` varchar(1) NOT NULL COMMENT 'Admin',
  `remember_me` tinyint(4) NOT NULL COMMENT 'Remember me',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;

INSERT INTO `ciauth_user_accounts` (`user_id`, `email`, `username`, `password`, `creation_date`, `last_login`, `admin`, `remember_me`) VALUES ('1', 'testuser@free.fr', 'testuser', '$2y$10$djD76XjDukyFZKNhexQ/PezRCXkoha0nIoL9TdNlw26tQkoou7gt2', '2015-08-18 11:14:20', '2015-10-30 15:32:17', '0', '0');
INSERT INTO `ciauth_user_accounts` (`user_id`, `email`, `username`, `password`, `creation_date`, `last_login`, `admin`, `remember_me`) VALUES ('2', 'testmanager@free.fr', 'testmanager', '$2y$10$x4HApygsiGTyK0lsUwn2/OPE/S3Drf88JfjiNe8Ly6x7EfHQCxMcG', '0000-00-00 00:00:00', '2015-10-30 15:32:17', '1', '0');
INSERT INTO `ciauth_user_accounts` (`user_id`, `email`, `username`, `password`, `creation_date`, `last_login`, `admin`, `remember_me`) VALUES ('3', 'testadmin@free.fr', 'testadmin', '$2y$10$XaKerwXTrbgkWt/jPm6YSuRVYy9H6xLUTUOCL.BCIUkMyNVOSqyP6', '2015-08-18 15:35:34', '2015-10-30 15:32:17', 'Y', '0');
INSERT INTO `ciauth_user_accounts` (`user_id`, `email`, `username`, `password`, `creation_date`, `last_login`, `admin`, `remember_me`) VALUES ('5', 'testgroup@free.fr', 'testgroup', '$2y$10$h8EzEzZGyeUwMRbUQPjzC.3Kf3T9r9BMTo1z9N1vJtwWtbX6WCvVe', '2015-08-10 03:04:10', '2015-10-30 15:32:17', '', '0');
INSERT INTO `ciauth_user_accounts` (`user_id`, `email`, `username`, `password`, `creation_date`, `last_login`, `admin`, `remember_me`) VALUES ('15', 'titi@free.fr', 'titi', '$2y$10$ZoY.J5ZyR4MLxyB4P0SQae5ZWMLQMW6/10w2tqfKpIomvSeKTW9KK', '2015-10-22 17:01:46', '2015-10-30 15:32:17', '', '0');
INSERT INTO `ciauth_user_accounts` (`user_id`, `email`, `username`, `password`, `creation_date`, `last_login`, `admin`, `remember_me`) VALUES ('28', 'testing@free.fr', 'testing', '$2y$10$z7ilTW5hNrRWDyAET5CEZ.FSxvGNnHTYvHJU362pd0nnuSOpYLCGG', '2015-10-30 15:25:00', '2015-10-30 15:32:17', '', '0');


#
# TABLE STRUCTURE FOR: ciauth_sessions
#

DROP TABLE IF EXISTS `ciauth_sessions`;

CREATE TABLE `ciauth_sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data` longtext,
  `rnd_key` longtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=895 DEFAULT CHARSET=utf8;

INSERT INTO `ciauth_sessions` (`id`, `user_id`, `ip_address`, `timestamp`, `data`, `rnd_key`) VALUES ('877', '1', '0.0.0.0', '2015-10-30 10:44:01', 'UEp1MVhpSXcxOHBIVUhjS0J0c0VvZz09', 'a436ca57db77d12b14644b61ec463fbb69e88cd6c6724f9d05f3e8b7d0b7d252');
INSERT INTO `ciauth_sessions` (`id`, `user_id`, `ip_address`, `timestamp`, `data`, `rnd_key`) VALUES ('894', '3', '127.0.0.1', '2015-10-30 15:32:17', 'blZSVWJLUjdiTXRtUnErNkZwT3g3dz09', '32a55b5ba1dca6470220688e4f5f6eaa4a046e3c5f940139bdbc4660431c33f6');


#
# TABLE STRUCTURE FOR: ciauth_navigation
#

DROP TABLE IF EXISTS `ciauth_navigation`;

CREATE TABLE `ciauth_navigation` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `order` bigint(20) NOT NULL,
  `name` varchar(60) NOT NULL,
  `anchor` varchar(60) NOT NULL,
  `parent` bigint(20) DEFAULT NULL,
  `permissions` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

INSERT INTO `ciauth_navigation` (`id`, `order`, `name`, `anchor`, `parent`, `permissions`) VALUES ('1', '1', 'Dev', '', NULL, '2');
INSERT INTO `ciauth_navigation` (`id`, `order`, `name`, `anchor`, `parent`, `permissions`) VALUES ('2', '1', 'Phpinfo', '/dev/phpinfo', '1', NULL);
INSERT INTO `ciauth_navigation` (`id`, `order`, `name`, `anchor`, `parent`, `permissions`) VALUES ('3', '2', 'Info', '/dev/info', '1', NULL);
INSERT INTO `ciauth_navigation` (`id`, `order`, `name`, `anchor`, `parent`, `permissions`) VALUES ('4', '3', 'Admin', '', NULL, NULL);
INSERT INTO `ciauth_navigation` (`id`, `order`, `name`, `anchor`, `parent`, `permissions`) VALUES ('5', '1', 'Configuration', '/admin/config', '4', NULL);
INSERT INTO `ciauth_navigation` (`id`, `order`, `name`, `anchor`, `parent`, `permissions`) VALUES ('6', '2', 'Database', '', '4', '2');
INSERT INTO `ciauth_navigation` (`id`, `order`, `name`, `anchor`, `parent`, `permissions`) VALUES ('7', '1', 'Backup', '/database/backup', '6', NULL);
INSERT INTO `ciauth_navigation` (`id`, `order`, `name`, `anchor`, `parent`, `permissions`) VALUES ('8', '1', 'Restore', '/database/restore', '6', NULL);
INSERT INTO `ciauth_navigation` (`id`, `order`, `name`, `anchor`, `parent`, `permissions`) VALUES ('9', '2', 'Migration', '/database/migration', '6', NULL);
INSERT INTO `ciauth_navigation` (`id`, `order`, `name`, `anchor`, `parent`, `permissions`) VALUES ('10', '3', 'Schema', '/database/schema', '6', NULL);
INSERT INTO `ciauth_navigation` (`id`, `order`, `name`, `anchor`, `parent`, `permissions`) VALUES ('11', '4', 'Default tables', '/database/default', '6', NULL);
INSERT INTO `ciauth_navigation` (`id`, `order`, `name`, `anchor`, `parent`, `permissions`) VALUES ('12', '5', 'Lock site', '/admin/lock', '4', NULL);
INSERT INTO `ciauth_navigation` (`id`, `order`, `name`, `anchor`, `parent`, `permissions`) VALUES ('13', '6', 'Users Management', '/users', '4', NULL);
INSERT INTO `ciauth_navigation` (`id`, `order`, `name`, `anchor`, `parent`, `permissions`) VALUES ('14', '7', 'Menus', '/C_ciauth_admin/nav_admin', '4', NULL);
INSERT INTO `ciauth_navigation` (`id`, `order`, `name`, `anchor`, `parent`, `permissions`) VALUES ('15', '4', 'CRUD', '', NULL, NULL);
INSERT INTO `ciauth_navigation` (`id`, `order`, `name`, `anchor`, `parent`, `permissions`) VALUES ('16', '1', 'List', '/crud/list', '15', NULL);
INSERT INTO `ciauth_navigation` (`id`, `order`, `name`, `anchor`, `parent`, `permissions`) VALUES ('17', '2', 'Create', '/crud/create', '15', '2');
INSERT INTO `ciauth_navigation` (`id`, `order`, `name`, `anchor`, `parent`, `permissions`) VALUES ('18', '5', 'Help', '', NULL, NULL);
INSERT INTO `ciauth_navigation` (`id`, `order`, `name`, `anchor`, `parent`, `permissions`) VALUES ('19', '1', 'About', '/about', '18', NULL);


